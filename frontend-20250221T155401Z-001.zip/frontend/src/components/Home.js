import React from 'react'
 import './home.css';

function Home() {
    
  return (
    <div >
        <div className='hometext' >
      <h1 id='welcome'>Welcome To FitTracker</h1>
      <p>where you can Track your workouts and much more</p>
    </div>
    </div>
    
  )
}

export default Home
