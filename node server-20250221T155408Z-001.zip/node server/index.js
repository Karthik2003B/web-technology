const express=require('express');
const cors=require('cors');
const bodyParser=require('body-parser');
const mongoose=require('mongoose');
const RegisterModel=require('./models/register');

main().catch(err => console.log(err));

async function main() {
  await mongoose.connect('mongodb://127.0.0.1:27017/demo');
  console.log('db connected')

  // use `await mongoose.connect('mongodb://user:password@127.0.0.1:27017/test');` if your database has auth enabled
}
const userSchema = new mongoose.Schema({
    exerciseName: String,
    numberOfSets: Number,
  numberOfReps: Number,
  weight: Number,
  time: Number
  });
  const User=mongoose.model('Workouts',userSchema);

const server=express();

server.use(cors());
server.use(bodyParser.json());
server.post('/demo',async (req,res)=>{
    let user=new User();
    user.exerciseName=req.body.exerciseName;
    user.numberOfReps=req.body.numberOfReps;
    user.numberOfSets=req.body.numberOfSets;
    user.weight=req.body.weight;
    user.time=req.body.time;
    const doc=await user.save()

    console.log(doc)
    res.json(doc);
})

// server.post('/demo',async (req,res)=>{
//   let register=new RegisterModel();
//  register.username=req.body.username;
//  register.email=req.body.email;
//  register.password=req.body.password;
//   const doc=await register.save()

//   console.log(doc)
//   res.json(doc);
// })



server.listen(8080,()=>{
    console.log('server started')
})
